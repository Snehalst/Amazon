package Amazon_TestclassPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import amazon_Pomclass.HomePomClassAmazon;

import amazon_Pomclass.TestBaseclass;

public class TC02_VerifyFilterFunctionality extends TestBaseclass {


		
	@Test
	public void VerifyLogout()
	{
		HomePomClassAmazon hp=new HomePomClassAmazon(driver);
		hp.SendProductname();
		System.out.println("product name send");
		hp.clickfitureDropDown();
		System.out.println("clicked on feature filture");
		hp.clickonHightoLowDropDown();
		System.out.println("selected high to low feature");
		System.out.println( "text of fituredropdown"+hp.GetTextofFeatureBtn());
	
		System.out.println("apply assertion");
		String Expectedtext="Sort by:Price: High to Low";
		String ActualText= hp.GetTextofFeatureBtn();
		
		
		Assert.assertEquals(ActualText, Expectedtext);
		
		
		
		
	}
	
	
	
}
