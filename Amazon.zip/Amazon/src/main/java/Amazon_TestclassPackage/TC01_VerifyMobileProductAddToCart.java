package Amazon_TestclassPackage;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import UtilityPackage_Saucedemo.Utilityclass;
import amazon_Pomclass.HomePomClassAmazon;

import amazon_Pomclass.ProductDetailPomclassAmazon;
import amazon_Pomclass.TestBaseclass;

public class TC01_VerifyMobileProductAddToCart extends TestBaseclass{

	@Test
	public void VerifyBagProductAddTOCart() throws InterruptedException
	{
	
		HomePomClassAmazon hp=new HomePomClassAmazon(driver);
		hp.SendProductname();
		System.out.println("productname is send");
		hp.ClickonMobProcuct();
		System.out.println("clicked on mobileProduct");
		
		ProductDetailPomclassAmazon pp=new ProductDetailPomclassAmazon(driver);
		pp.SwitchSeleniumSecondPage();
		System.out.println("selenium focus switch on Mobile productdetailpage");
		
		pp.ClickonMobAddToCartBtn();
		
		System.out.println("clicked on mobile add to cart");
		pp.clickonCartBtn();
		
		System.out.println("apply assertion");
		System.out.println("text of addtocartbtn ->" +  pp.GetTextofAddToCartBtn());
		
		String exepctedProductCount ="1";
		String actualProductCount =pp.GetTextofAddToCartBtn();
		
		
		Assert.assertEquals(actualProductCount, exepctedProductCount);
		
		
		
	}
	
	
}
