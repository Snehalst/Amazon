package amazon_Pomclass;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductDetailPomclassAmazon {

	private WebDriver driver;
	 private WebDriverWait wait;
	
	
	 public void SwitchSeleniumSecondPage()
	 {
		 List<String> allPageAddresses = new ArrayList<String>(driver.getWindowHandles());
		 driver.switchTo().window(allPageAddresses.get(1));
	 
	 }
	 
	
	
	@FindBy(xpath ="//input[@id='add-to-cart-button']")
	private WebElement MobAddToCartBtn;
	
	public void ClickonMobAddToCartBtn() 
	{
		
		MobAddToCartBtn.click();
		 if (MobAddToCartBtn.isEnabled()) {
			 MobAddToCartBtn.click();
		 } else {
		     System.out.println("Element is not enabled and cannot be interacted with.");
		 }

		

		
	}
	
	
	@FindBy(xpath ="//html//body//div[12]//div[3]//div[3]//div//div[1]//div[3]//div[1]//div[2]//div[3]//form//span//span//input")
	private WebElement Cartbutton;
	
	public void clickonCartBtn()
	{
		Cartbutton.click();

	}
	
	
	
	@FindBy(xpath ="//span[@id='nav-cart-count']")
	private WebElement AddToCartlink;
	
	public String GetTextofAddToCartBtn()
	{
		String actualCount= AddToCartlink.getText();
		return actualCount;

	}
	
	
	
	
	
	
	public ProductDetailPomclassAmazon(WebDriver driver)
	{
		this.driver=driver;
		this.wait = new WebDriverWait(driver, 10);
		PageFactory.initElements(driver, this);
	}
	
	
	
}
