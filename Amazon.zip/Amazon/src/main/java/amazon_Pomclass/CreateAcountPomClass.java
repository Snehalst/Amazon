package amazon_Pomclass;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CreateAcountPomClass {
	
	private WebDriver driver;

	public void SwitchSeleniumCreateAccountPage()
	 {
		 List<String> allPageAddresses = new ArrayList<String>(driver.getWindowHandles());
		 driver.switchTo().window(allPageAddresses.get(2));
	 
	 }
	
	@FindBy(xpath ="//input[@id='ap_customer_name']")
	private WebElement Yourname;

	public void SendYourname()
	{
		Yourname.sendKeys("Snehal Tungatkar");
		
	}
	
	@FindBy(xpath ="//input[@id='ap_phone_number']")
	private WebElement Mobilenumber;

	public void SendMobilenumber()
	{
		Mobilenumber.sendKeys("9764772088");
		
	}
    
	@FindBy(xpath ="//input[@id='ap_password']")
	private WebElement password;

	public void Sendpassword()
	{
		Mobilenumber.sendKeys("Sneha@0");
		
	}
    
	@FindBy(xpath ="//input[@id='continue']")
	private WebElement verifymobbtn;

	public void clickonVerifymobBtn()
	{
		verifymobbtn.click();
		
	}
	
	public CreateAcountPomClass(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		
	}
	
	
	
}
