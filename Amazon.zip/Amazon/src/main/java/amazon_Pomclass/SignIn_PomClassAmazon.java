package amazon_Pomclass;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignIn_PomClassAmazon {

	private WebDriver driver;
	
	
	public void switchToSignInWindow() {
		List<String> allPagehandles = new ArrayList<String>(driver.getWindowHandles());
		 driver.switchTo().window(allPagehandles.get(1));
        
    }
	 

	
	 @FindBy(xpath ="//html//body//div[1]//div[1]//div[2]//div//div[2]//div[2]//span//span//a")
		private WebElement CreateUrAmazonAc;

		public void clickonCreateUrAmazonAc() throws InterruptedException
		{
			Thread.sleep(5000);
			CreateUrAmazonAc.click();
			if (CreateUrAmazonAc.isEnabled()) {
				CreateUrAmazonAc.click();
			 } else {
			     System.out.println("Element is not enabled and cannot be interacted with.");
			 }
		}
	

	public SignIn_PomClassAmazon(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		
	}
}
