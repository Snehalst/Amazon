package amazon_Pomclass;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class HomePomClassAmazon {

	private WebDriver driver;
	private Actions act;
	
	
	
	@FindBy(xpath ="//input[@id='twotabsearchtextbox']")
	private WebElement Searchbox;
	
	@FindBy(xpath ="//input[@id='nav-search-submit-button']")
	private WebElement Searchbtn;

	public void SendProductname()
	{
		Searchbox.sendKeys("iPhone");
		Searchbtn.click();
	}
	
	
	@FindBy(xpath ="(//img[@class='s-image'])[1]")
	private WebElement FirstMobile;
	
	public void ClickonMobProcuct()
	{
		FirstMobile.click();
	}
	
    @FindBy(xpath ="//span[@id='a-autoid-0-announce']")
	private WebElement fitureDropDown;
    
    public void clickfitureDropDown()
    {
    	act.click(fitureDropDown).perform();
    	   	
    }

              
	
	
    @FindBy(xpath ="//html//body//div[4]//div//div//ul//li[3]//a")
   	private WebElement SelectHightoLowDropDown;
    
    public void clickonHightoLowDropDown()
    {
    	act.click(SelectHightoLowDropDown).perform();
    	   	
    }
	
    
    public String GetTextofFeatureBtn()
	{
		String actualfeaturetext= fitureDropDown.getText();
		return actualfeaturetext;

	}
    
//    @FindBy(xpath ="//span[@id='nav-link-accountList-nav-line-1']")
//   	private WebElement Registeruserlink;
//
//   	public void ClickOnRegisteruserlink()
//   	{
//   		Registeruserlink.click();
//   		
//   	}
    
   	
   	@FindBy(xpath ="(//a[text()='Start here.'])[2]")
   	private WebElement clickherelink;

   	public void clickHerelink() throws InterruptedException
   	{
   		Thread.sleep(5000);
   		act.click(clickherelink).perform();
   		
   	}	
   	
   	
   	
   	
   	
   
	public HomePomClassAmazon(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		act=new Actions(driver);
		
	}
	
	
	
}
